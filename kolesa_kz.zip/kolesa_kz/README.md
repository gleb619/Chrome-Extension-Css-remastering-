# Chrome-Extension-Css-remastering-
This app show how create simple chrome extension and communicate with content script via chrome.tabs.sendMessage
![helper](https://github.com/gleb619/Chrome-Extension-Css-remastering-/raw/master/helper.jpg)
