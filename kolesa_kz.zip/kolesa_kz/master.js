(function() {

	var root = this;
	var app = {};

	// Use in node or in browser
	if (typeof exports !== 'undefined') {
		module.exports = app;
	} else {
		root.app = app;
	}
  
  /*------------------------------------------------------------*/
  
	function init(){
		onMessageReceive();
		console.clear();
		hookTabClick();
		hook();
	}

	
	/*------------------------------------------------------------*/
  
	function onMessageReceive(){
		chrome.extension.onMessage.addListener(function(request, sender, sendResponse) {
			switch(request.type) {
				case "repaint":
					render(request.data);
				break;
			}
			return true;
		});
	}

	function loadSettings(){
		loadSetingsData(function (result) {	
			render(result.remaster_settings);
		});
	}

	function render(values){
		changeMainPage(values);
		changeModule(values);
	}
	
	function loadSetingsData(callback){
		chrome.storage.local.get('remaster_settings', callback);
	}
	
	
  /*------------------------------------------------------------*/

	function hook(){
		hideElements();
		addFakeSubmit();
		addFakePriceInput();

		var timer = setTimeout(function() {
			hideElements();
			addFakeSubmit();
			addFakePriceInput();

			clearTimeout(timer);
			timer = null;
		}, 300);
	}

  	//$("#search-form-content #sf_submit").parent().append("<input type='button' value='Найти' id='fake_sf_submit' class='rounded-button-yellow'>");
	function hideElements(){
		$("#search-form-content > table:nth-child(1) > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(1)").addClass("hide-element");
	};

	function addFakePriceInput(){
		console.log("addFakePriceInput#add bar");
		var selector = "#search-form-content > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(1)";
		var selectorFirstHint = "#fake_price_hint > span:nth-child(1)";
		var selectorSecondHint = "#fake_price_hint > span:nth-child(2)";
		var selectorThirdHint = "#fake_price_hint > span:nth-child(3)";
		var panel = "" +
			"<tr id='fake_price_bar'>" +
			"    <td class='top'>" +
			"        <strong>Цена</strong>" +
			"        <p>" +
			"            <input name='price[from]' type='text' value='' id='fake_price_l' size='6' class='validate'> " +
			"			 — " +
			"			 <input name='price[to]' type='text' value='' id='fake_price_h' size='6' class='validate'>" +
			"			 &nbsp;$" +
			"        </p>" +
			"        <nobr>" +
			"            <p id='fake_price_hint' class='hint'>" +
			"				<span data-type='price' data-h='1000000' class='action-link' style='visibility: visible;'>до&nbsp;5&nbsp;тыс.</span>" +
			"				<span data-type='price' data-l='1000000' data-h='2000000' class='action-link' style='visibility: visible;'>5&nbsp;тыс.&nbsp;—&nbsp;15&nbsp;тыс.</span>" +
			"				<span data-type='price' data-l='2000000' data-h='3000000' class='action-link' style='visibility: visible;'>15&nbsp;тыс.&nbsp;</span>" +
			"			</p>" +
			"		</nobr>" +
			"    </td>" +
			"</tr>";

		$("#fake_price_bar").remove();
		$(selectorFirstHint).off();
		$(selectorSecondHint).off();
		$(selectorThirdHint).off();
		$(selector).parent().prepend(panel);
		/* ------------------ */
		$(selectorFirstHint).on('click', function(e){
			e.preventDefault();
			$("#fake_price_l").val('');
			$("#fake_price_h").val(5000);
		});
		$(selectorSecondHint).on('click', function(e){
			e.preventDefault();
			$("#fake_price_l").val(5000);
			$("#fake_price_h").val(15000);
		});
		$(selectorThirdHint).on('click', function(e){
			e.preventDefault();
			$("#fake_price_l").val(15000);
			$("#fake_price_h").val('');
		});
		parseAndSetValue(366);
	}

	function addFakeSubmit(){
		console.log("addFakeSubmit#add button");
		$("#fake_sf_submit").off();
		$("#fake_sf_submit").remove();
		var selector = "#search-form-content #sf_submit";
		var button = "<input type='button' value='Найти' id='fake_sf_submit' class='rounded-button-yellow'>";
		$(selector).parent().append(button);
		$("#fake_sf_submit").on('click', function(e){
			e.preventDefault();
			console.info("addFakeSubmit#on find was clicked");
			convertAndSetValue(366);
			$("#sf_submit").trigger("click");
		});
	}

	function hookTabClick(){
		$("#search-form-header > ul > li > a").on('click', function(e){
			console.info("\n\n\n", "hookTabClick#on tab click");
			e.preventDefault();
			hook();
		});
	}

	function convertAndSetValue(rate){
		console.log("---------------");
		var from = parseInt($("#fake_price_l").val());
		var to = parseInt($("#fake_price_h").val());
		if (isNaN(from)){
			from = 0;
		}
		if (isNaN(to)){
			to = from + 5000;
		}
		console.info("convertAndSetValue#from: ", from);
		console.info("convertAndSetValue#to: ", to);
		var fromConverted = roundDown(Math.ceil(from * rate));
		var toConverted = roundDown(Math.ceil(to * rate));
		console.info("convertAndSetValue#fromConverted: ", fromConverted);
		console.info("convertAndSetValue#toConverted: ", toConverted);
		$("#price_l").val(fromConverted);
		$("#price_h").val(toConverted);
	}

	function parseAndSetValue(rate){
		console.log("---------------");
		var from = parseInt($("#price_l").val());
		var to = parseInt($("#price_h").val());
		if (isNaN(from)){
			from = 0;
		}
		if (isNaN(to)){
			to = from + 5000;
		}
		console.info("parseAndSetValue#from: ", from);
		console.info("parseAndSetValue#to: ", to);
		var fromParsed = Math.ceil(from / rate);
		var toParsed = Math.ceil(to / rate);
		console.info("parseAndSetValue#fromParsed: ", fromParsed);
		console.info("parseAndSetValue#toParsed: ", toParsed);
		$("#fake_price_l").val(fromParsed);
		$("#fake_price_h").val(toParsed);
	}

	function roundDown(value){
		return Math.round(value/1000)*1000;
	}


  /*------------------------------------------------------------*/

  init();

}());
